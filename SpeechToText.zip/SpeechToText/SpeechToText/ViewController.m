//
//  ViewController.m
//  SpeechToText
//
//  Created by Bommavaram, Sarika  . (UMKC-Student) on 6/19/15.
//  Copyright (c) 2015 Bommavaram, Sarika  . (UMKC-Student). All rights reserved.
//

#import "ViewController.h"

#import "AFHTTPRequestOperationManager.h"

#define BASE_URL "http://api.openweathermap.org/data/2.5/weather"


@interface ViewController ()
@property (strong, nonatomic) IBOutlet UILabel *messageLabel;
@property (strong, nonatomic) IBOutlet UITextField *searchTextField;
@property (strong, nonatomic) IBOutlet UITableView *tableViewDisplayDataArray;
@property (strong, nonatomic) IBOutlet UIButton *recordButton;
@property (strong, nonatomic) IBOutlet UILabel *labelMsg;

@end

const unsigned char SpeechKitApplicationKey[] = {0xd1, 0x92, 0xa8, 0x04, 0xff, 0x3f, 0x85, 0x4a, 0x90, 0x1a, 0x19, 0x4c, 0x23, 0xe7, 0x6b, 0xf7, 0xbb, 0xc6, 0xc9, 0xd4, 0x40, 0xa8, 0xd3, 0x96, 0xc7, 0x17, 0x9a, 0xa9, 0x2a, 0x98, 0xa3, 0xfb, 0x2b, 0x4b, 0xff, 0x2a, 0x8a, 0x85, 0x74, 0x1a, 0x9f, 0x8e, 0x66, 0xc2, 0x75, 0xd2, 0xb9, 0x30, 0x98, 0x83, 0x04, 0xd8, 0x2b, 0xd7, 0x6f, 0xf2, 0xee, 0x09, 0x9b, 0x19, 0xa1, 0x3e, 0x14, 0xcc};

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
        [SpeechKit setupWithID: @"NMDPTRIAL_ssarika535_gmail_com20150619141245"
                          host:@"sslsandbox.nmdp.nuancemobility.net"
                          port:443
                        useSSL:YES
                      delegate:nil];
        
        // Set earcons to play
        SKEarcon* earconStart	= [SKEarcon earconWithName:@"earcon_listening.wav"];
        SKEarcon* earconStop	= [SKEarcon earconWithName:@"earcon_done_listening.wav"];
        SKEarcon* earconCancel	= [SKEarcon earconWithName:@"earcon_cancel.wav"];
        
        [SpeechKit setEarcon:earconStart forType:SKStartRecordingEarconType];
        [SpeechKit setEarcon:earconStop forType:SKStopRecordingEarconType];
        [SpeechKit setEarcon:earconCancel forType:SKCancelRecordingEarconType];
    
    
    self.messageLabel.text = @"Tap on the mic";
  
    
    if (!self.tableViewDisplayDataArray) {
        self.tableViewDisplayDataArray = [[NSMutableArray alloc] init];
    }
    
    
  
    
    self.searchTextField.returnKeyType = UIReturnKeySearch;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)tappedVoiceButton:(id)sender {
    
    self.recordButton.selected = !self.recordButton.isSelected;
    
    // This will initialize a new speech recognizer instance
    if (self.recordButton.isSelected) {
        self.voiceSearch = [[SKRecognizer alloc] initWithType:SKSearchRecognizerType
                                                    detection:SKShortEndOfSpeechDetection
                                                     language:@"en_US"
                                                     delegate:self];
    }
    
    // This will stop existing speech recognizer processes
    else {
        if (self.voiceSearch) {
            [self.voiceSearch stopRecording];
            [self.voiceSearch cancel];
        }
    }
}


# pragma mark - SKRecognizer Delegate Methods

- (void)recognizerDidBeginRecording:(SKRecognizer *)recognizer {
    self.messageLabel.text = @"Listening..";
}

- (void)recognizerDidFinishRecording:(SKRecognizer *)recognizer {
    self.messageLabel.text = @"Done Listening..";
}

- (void)recognizer:(SKRecognizer *)recognizer didFinishWithResults:(SKRecognition *)results {
    long numOfResults = [results.results count];
    
    if (numOfResults > 0) {
        // update the text of text field with best result from SpeechKit
        self.searchTextField.text = [results firstResult];
        [_searchTextField resignFirstResponder];  //To hide the keyboard
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        NSString *sentense = [_searchTextField.text stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
        
        NSString *url = [NSString stringWithFormat:@"%s?q=%@", BASE_URL, sentense];
        
        NSLog(@"%@", url);
        
        [manager GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSLog(@"JSON: %@", responseObject);
            
            NSDictionary *dict = [responseObject objectForKey:@"main"];
            
            NSString *temp=[dict objectForKey:@"temp"];
            //_tags = [responseObject objectForKey:@"tags"];
            
            self.labelMsg.text=[NSString stringWithFormat:@"%@", temp];;
            
            NSLog(@"Data%@",temp);
            
            
            //[_responseTableView reloadData];
            
            
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            NSLog(@"Error: %@", error);
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error"
                                                            message:[error description]
                                                           delegate:nil
                                                  cancelButtonTitle:@"Ok"
                                                  otherButtonTitles:nil, nil];
            [alert show];
        }];

        
    }
    
    self.recordButton.selected = !self.recordButton.isSelected;
    
    if (self.voiceSearch) {
        [self.voiceSearch cancel];
    }
}

- (void)recognizer:(SKRecognizer *)recognizer didFinishWithError:(NSError *)error suggestion:(NSString *)suggestion {
    self.recordButton.selected = NO;
    self.messageLabel.text = @"Connection error";
   
    
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error"
                                                    message:[error localizedDescription]
                                                   delegate:nil
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles:nil];
    [alert show];
}

@end
