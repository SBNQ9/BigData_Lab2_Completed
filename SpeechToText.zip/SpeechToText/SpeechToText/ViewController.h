//
//  ViewController.h
//  SpeechToText
//
//  Created by Bommavaram, Sarika  . (UMKC-Student) on 6/19/15.
//  Copyright (c) 2015 Bommavaram, Sarika  . (UMKC-Student). All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SpeechKit/SpeechKit.h>

@interface ViewController : UIViewController <UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource, SpeechKitDelegate, SKRecognizerDelegate>
@property (strong,nonatomic) SKRecognizer* voiceSearch;


@end

